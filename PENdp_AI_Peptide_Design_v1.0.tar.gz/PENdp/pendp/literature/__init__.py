# literature module
